import jeliot.io.*;

class SimpleExample {
	static void main() {
		
		int a = Input.readInt();
		int b = Input.readInt();
		int c = a * b;
		Output.println(c);
	}
} 
