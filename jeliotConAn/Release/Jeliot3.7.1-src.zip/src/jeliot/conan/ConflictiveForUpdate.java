package jeliot.conan;

public class ConflictiveForUpdate extends Conflict {

	public ConflictiveForUpdate(int line) {
		super(Conflict.FOR, line);		
		
	}
	

}
