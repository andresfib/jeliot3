/*
 * Created on 29.10.2004
 */
package jeliot.theater;


/**
 * @author Niko Myller
 */
public interface PauseListener {

    public void paused();
}
