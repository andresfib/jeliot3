package jeliot.calltree;


/**
 * @author Niko Myller
 */
public class Util {
    
    /**
     * Comment for <code>nullObject</code>
     */
    public static final Object nullObject = new Object();
    
}
